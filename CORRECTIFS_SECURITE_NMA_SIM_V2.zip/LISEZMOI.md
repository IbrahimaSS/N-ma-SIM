# Correctifs de sécurité N'ma SIM — parcours ligne par ligne (v2)

Ce dossier contient 31 fichiers modifiés ou ajoutés. Il remplace le lot précédent
(24 fichiers) — reprends tout depuis celui-ci, il inclut déjà tout l'ancien travail.

## Comment les appliquer

Identique à avant : remplace chaque fichier au même chemin dans ton dépôt local,
ajoute les 2 fichiers nouveaux (backend/lib/rate-limit.ts et
frontend/src/lib/rate-limit.ts), ajoute les variables d'environnement (voir plus
bas), teste en local, puis commit + push.

## 7 NOUVELLES failles trouvées dans cette passe (absentes du document précédent)

| ID | Faille | Fichier | Gravité |
|---|---|---|---|
| F19 | Redirection non validée depuis une réponse IA (panel admin) | frontend/src/components/admin/AdminAgentIA.tsx | Moyenne |
| F20 | Redirection non validée depuis une réponse IA (borne) | frontend/src/components/borne/AgentIA.tsx | Moyenne |
| F21 | Upload KYC sans limite de taille/type ni rate-limit | frontend/src/app/api/kyc/route.ts | Élevée |
| F22 | GET /api/parametres accessible à tout rôle authentifié (fuite de la clé API en clair) | backend/app/api/parametres/route.ts | Élevée |
| F23 | Fuite de données personnelles non authentifiée (nom, tél, email, historique par numéro de pièce) | backend/app/api/clients/check/route.ts | Élevée (partiellement corrigée, voir note) |
| F24 | Bouton "Sauvegarde"/"Rapport PDF" appelait /api/system/backup sans token (aurait cassé après F02) | frontend/src/app/admin/parametres/page.tsx | Bug fonctionnel lié à F02 |

### Détail F19/F20 — Redirection non validée
Le composant assistant IA (borne et admin) appelait `router.push(action.target)`
avec une valeur venant directement de la réponse JSON du modèle Groq, sans
vérifier qu'il s'agit d'un chemin interne. Une réponse manipulée (injection de
prompt dans le message envoyé au modèle) pouvait en théorie faire naviguer le
navigateur vers une URL externe. Correctif : n'accepter que les cibles
commençant par "/".

### Détail F21 — Upload KYC
`/api/kyc` est un endpoint public (utilisé par tout visiteur de la borne, sans
compte). Il transmettait n'importe quel fichier, de n'importe quelle taille, au
microservice Python sans limite. Correctif : taille max 8 Mo, type MIME
`image/*` obligatoire, limite de 15 requêtes/minute par IP.

### Détail F22 — Fuite de la clé API via /api/parametres
Le POST (modification) exigeait déjà un rôle ADMIN, mais le GET (lecture)
n'exigeait qu'une simple authentification — n'importe quel rôle, y compris
LECTURE_SEULE, pouvait lire le champ "Clé secrète API (Token)" en clair.
Correctif : GET restreint à ADMIN, comme POST.

### Détail F23 — /api/clients/check (IMPORTANT — lire avant de considérer que c'est réglé)
C'est la faille la plus sérieuse trouvée dans cette passe. Cet endpoint est
appelé **directement depuis le navigateur** (fetch côté client dans
`verification/resultat/page.tsx`), sans authentification, avec le numéro de
pièce d'identité en paramètre d'URL. Avant tout correctif, n'importe qui pouvait
interroger n'importe quel numéro de pièce et récupérer nom, téléphone, email,
statut et historique complet des demandes de cette personne.

Le correctif appliqué (rate-limit de 10 requêtes/minute par IP) RALENTIT
l'énumération automatisée mais NE RÈGLE PAS le problème de fond : rien ne
prouve que l'appelant a réellement scanné cette pièce d'identité sur la borne.
Une vraie correction demande un jeton court, signé côté serveur, émis
uniquement après la vérification OCR + selfie pour CE numéro de pièce précis,
et exigé par cet endpoint. Ce n'est PAS implémenté ici — c'est un chantier à
part entière (modification du flux de vérification KYC), à traiter en priorité
avant toute mise en production réelle avec de vraies données de citoyens.

### Détail F24 — Bug introduit par le correctif F02
En sécurisant /api/system/backup (exige un ADMIN), les deux boutons du panel
admin qui l'appelaient sans aucun en-tête (un simple lien `<a href>` et un
`fetch()` nu) auraient cassé. Corrigé pour utiliser `apiFetch` (qui ajoute le
token) et déclencher le téléchargement via un blob local.

## Fichiers de la passe précédente, inchangés depuis (F01-F18)
Voir le manifeste précédent pour le détail — tous ces fichiers sont réinclus
tels quels dans ce lot v2.

## Nouvelles variables d'environnement (en plus de celles déjà listées avant)
Aucune nouvelle variable requise pour cette passe.

## Ce qui reste non corrigé après cette passe (honnêteté du périmètre)

- **F12** — token JWT dans localStorage (nécessite une migration vers cookie httpOnly)
- **F13** — /docs et /api/docs publics (config d'infrastructure, pas du code)
- **F16** — scripts avec mot de passe par défaut committés
- **F23 (partie fond)** — voir note détaillée ci-dessus : le rate-limit ralentit
  mais ne bloque pas l'accès non autorisé aux données personnelles
- Composants UI simples (Badge, Button, Card, Input, Modal, Select, Stepper,
  EmptyState, StatusBadge) relus rapidement : aucun problème trouvé, mais pas
  d'analyse approfondie ligne par ligne au même niveau que les endpoints API
- Dépendances npm/pip (package.json, requirements.txt) : non vérifiées contre
  une base de vulnérabilités connues (CVE). Recommandation : lancer
  `npm audit` dans backend/ et frontend/, et `pip-audit` ou similaire dans
  nma_kyc_api/, régulièrement
- Le microservice Python (`nma_kyc/core.py`, `antispoof.py`) a été relu pour
  des patterns dangereux évidents (injection de commande, désérialisation non
  sûre) — rien trouvé — mais pas audité en profondeur sur la logique métier
  (par exemple la fiabilité du seuil de similarité faciale, qui est un sujet
  de robustesse du modèle IA, pas de cybersécurité classique)
