// =============================================
// LIMITATION DE DÉBIT SIMPLE (en mémoire, par clé)
// Copie du module backend/lib/rate-limit.ts, dupliquée ici car le frontend
// est une application Next.js séparée du backend et ne partage pas ses libs.
// Pour plusieurs instances en production, remplacer par un store partagé (Redis).
// =============================================

interface Entry {
  count: number
  resetAt: number
}

const store = new Map<string, Entry>()

export function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now()
  const entry = store.get(key)

  if (!entry || now > entry.resetAt) {
    store.set(key, { count: 1, resetAt: now + windowMs })
    return true
  }

  if (entry.count >= max) {
    return false
  }

  entry.count += 1
  return true
}

setInterval(() => {
  const now = Date.now()
  for (const [key, entry] of store.entries()) {
    if (now > entry.resetAt) store.delete(key)
  }
}, 5 * 60 * 1000).unref?.()

export function getClientIp(request: Request): string {
  const forwarded = request.headers.get('x-forwarded-for')
  if (forwarded) return forwarded.split(',')[0].trim()
  return request.headers.get('x-real-ip') || 'unknown'
}
