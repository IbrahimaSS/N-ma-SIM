import { NextResponse } from "next/server";

const BACKEND_URL = process.env.BACKEND_URL || "http://localhost:3001";

/**
 * Route proxy : appelée par la borne quand le client clique sur "Terminer".
 * Elle met à jour le statut de la demande à VALIDEE dans le backend admin.
 */
export async function POST(request: Request) {
  try {
    // Correctif F09 — plus de valeur par défaut devinable ("kiosk-system") :
    // si le secret n'est pas configuré, on échoue explicitement (fail-closed)
    // au lieu de démarrer avec un secret prévisible.
    const kioskToken = process.env.KIOSK_SYSTEM_TOKEN;
    if (!kioskToken) {
      console.error("[TERMINER] KIOSK_SYSTEM_TOKEN manquant — configuration invalide");
      return NextResponse.json({ success: false, error: "Configuration serveur invalide" }, { status: 500 });
    }

    const { demandeId } = await request.json();

    if (!demandeId) {
      return NextResponse.json({ error: "demandeId manquant" }, { status: 400 });
    }

    const res = await fetch(`${BACKEND_URL}/api/demandes/${demandeId}`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        // Correctif F04 — même secret partagé que les autres appels internes borne
        "x-kiosk-token": kioskToken,
      },
      body: JSON.stringify({
        statut: "VALIDEE",
        commentaireAdmin: "Validation automatique borne libre-service.",
        verificationOCR: true,
        verificationSelfie: true,
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      console.error("[TERMINER] Erreur backend:", err);
      // On ne bloque pas l'utilisateur — on log et on continue
      return NextResponse.json({ success: false, error: "Erreur mise à jour statut" }, { status: 200 });
    }

    const data = await res.json();
    return NextResponse.json({ success: true, demande: data.data });

  } catch (error) {
    console.error("[TERMINER ERROR]", error);
    // Graceful degradation — ne pas bloquer la navigation
    return NextResponse.json({ success: false, error: "Erreur serveur" }, { status: 200 });
  }
}
