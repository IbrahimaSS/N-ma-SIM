import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    // Correctif F09 — plus de valeur par défaut ("VOTRE_LICENSE_KEY_TEST") :
    // sans clé réelle configurée, on refuse la requête plutôt que d'appeler
    // Lengo Pay avec des identifiants invalides/prévisibles.
    const licenseKey = process.env.LENGO_LICENSE_KEY;
    const websiteId = process.env.LENGO_WEBSITE_ID;
    if (!licenseKey || !websiteId) {
      console.error("[API PAIEMENT] LENGO_LICENSE_KEY ou LENGO_WEBSITE_ID manquant");
      return NextResponse.json({ error: "Configuration de paiement invalide" }, { status: 500 });
    }

    const body = await request.json();
    const { amount, currency = "GNF" } = body;

    // L'URL de retour pointera vers notre page spéciale d'iframe-callback
    // On utilise l'origine de la requête entrante
    const url = new URL(request.url);
    const returnUrl = `${url.origin}/borne/nouvelle-sim/paiement-callback`;

    const payload = {
      websiteid: websiteId,
      amount: amount,
      currency: currency,
      return_url: returnUrl,
    };

    const response = await fetch("https://sandbox.lengopay.com/api/v1/payments", {
      method: "POST",
      headers: {
        "Authorization": `Basic ${licenseKey}`,
        "Accept": "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if (!response.ok || data.status !== "Success") {
      console.error("[LENGO PAY ERROR]", data);
      return NextResponse.json({ error: "Erreur lors de la génération du paiement Lengo Pay", details: data }, { status: 500 });
    }

    return NextResponse.json({
      pay_id: data.pay_id,
      payment_url: data.payment_url
    });

  } catch (error) {
    console.error("[API PAIEMENT ERROR]", error);
    return NextResponse.json({ error: "Erreur serveur interne" }, { status: 500 });
  }
}
