# Correctifs de sécurité N'ma SIM — mode d'emploi

Ce dossier contient uniquement les fichiers modifiés ou ajoutés (24 fichiers).
Aucun autre fichier du dépôt n'a été touché.

## Comment les appliquer

1. Dans ton dépôt local N-ma-SIM, remplace chaque fichier ci-dessous par la version
   de ce dossier (même chemin relatif).
2. Deux fichiers sont NOUVEAUX (n'existent pas encore dans le dépôt) :
   - backend/lib/rate-limit.ts
3. Ajoute les variables d'environnement listées plus bas dans le `.env` du backend
   ET dans celui du frontend (jamais commitées dans Git).
4. Vérifie que le build passe (`npm run build` dans backend/ et frontend/).
5. Commit + push comme d'habitude.

## Nouvelles variables d'environnement à définir

### backend/.env
```
KIOSK_SYSTEM_TOKEN=<générer avec: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))">
ADMIN_ORIGIN=https://admin.nmasim.gn      # à adapter à ton vrai domaine admin
BORNE_ORIGIN=https://borne.nmasim.gn      # à adapter à ton vrai domaine borne
```

### frontend/.env
```
KIOSK_SYSTEM_TOKEN=<LA MÊME VALEUR que côté backend>
LENGO_LICENSE_KEY=<ta vraie clé Lengo Pay>
LENGO_WEBSITE_ID=<ton vrai website id Lengo Pay>
```

### nma_kyc_api/.env (optionnel, sinon retombe sur localhost:3000)
```
KYC_ALLOWED_ORIGINS=https://borne.nmasim.gn
```

Important : KIOSK_SYSTEM_TOKEN doit être IDENTIQUE côté backend et côté frontend
(c'est un secret partagé), et ne doit jamais être préfixé NEXT_PUBLIC_ (sinon il
serait visible dans le navigateur).

## Liste des fichiers et faille corrigée

| Fichier | Faille |
|---|---|
| backend/lib/auth.ts | F01–F09 (ajout de requireRole et isTrustedKiosk) |
| backend/lib/rate-limit.ts | F11, F18 (nouveau fichier) |
| backend/app/api/system/wipe/route.ts | F01 |
| backend/app/api/system/backup/route.ts | F02 |
| backend/app/api/paiements/route.ts | F03, F15 |
| backend/app/api/paiements/[id]/route.ts | F10 |
| backend/app/api/demandes/[id]/route.ts | F04 |
| backend/proxy.ts | F05 |
| backend/app/api/bornes/route.ts | F06 |
| backend/app/api/bornes/[id]/route.ts | F06 |
| backend/app/api/auth/refresh/route.ts | F07 |
| backend/app/api/auth/login/route.ts | F11 |
| backend/app/api/debug-env/route.ts | F08 |
| backend/app/api/clients/[id]/route.ts | F10 |
| backend/app/api/logs/route.ts | F10 |
| backend/app/api/admin-agent/route.ts | F17, F18 |
| backend/app/api/agent-ia/route.ts | F18 |
| frontend/src/app/api/terminer-demande/route.ts | F04, F09 |
| frontend/src/app/api/paiement/route.ts | F09 |
| frontend/src/app/api/soumettre-demande/route.ts | F04 |
| frontend/src/app/api/soumettre-reactivation/route.ts | F04 |
| frontend/src/app/api/soumettre-recharge/route.ts | F04 |
| frontend/src/app/api/public/parametres/route.ts | F04 (nettoyage) |
| nma_kyc_api/nma_kyc_api/app.py | F14 |

## Ce qui n'est PAS corrigé dans ce lot (nécessite plus de travail)

- **F12** — migrer le token JWT admin de localStorage vers un cookie httpOnly
  (touche le frontend d'authentification et le backend de login en profondeur,
  à faire dans un lot séparé).
- **F13** — restreindre l'accès à /docs et /api/docs en production (config
  d'infrastructure : IP allowlist ou middleware d'auth basique, pas juste du code).
- **F16** — les scripts avec mot de passe par défaut (reset-password.ts, etc.)
  sont encore présents dans le dépôt. À déplacer hors du dossier déployé ou à
  faire lire le mot de passe depuis une variable d'environnement.

## Vérification recommandée avant de pousser

- Relire chaque fichier remplacé pour s'assurer qu'aucune autre modification
  locale n'a été écrasée par erreur (diff avant de commit).
- Tester en local : connexion admin, parcours borne complet (nouvelle SIM,
  recharge, réactivation), pour vérifier que le nouveau x-kiosk-token fonctionne
  bien de bout en bout.
- Une fois testé, régénérer KIOSK_SYSTEM_TOKEN pour l'environnement de
  production avec une valeur différente de celle utilisée en test.
