import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// Correctif F05 — liste blanche d'origines au lieu de refléter n'importe quelle
// origine avec Access-Control-Allow-Credentials: true. À adapter aux vrais
// domaines de production (borne + admin), et à définir via variable
// d'environnement pour ne pas coder les URLs en dur.
const ALLOWED_ORIGINS = [
  process.env.ADMIN_ORIGIN,
  process.env.BORNE_ORIGIN,
  process.env.NODE_ENV !== 'production' ? 'http://localhost:3000' : null,
].filter((o): o is string => !!o)

export function proxy(request: NextRequest) {
  const origin = request.headers.get('origin') ?? ''
  const isAllowed = ALLOWED_ORIGINS.includes(origin)

  // Headers CORS — origine autorisée uniquement, jamais reflétée à l'aveugle
  const corsHeaders = new Headers({
    'Access-Control-Allow-Origin': isAllowed ? origin : (ALLOWED_ORIGINS[0] ?? ''),
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, x-kiosk-token',
    'Access-Control-Allow-Credentials': 'true',
    'Vary': 'Origin',
  })

  // Répondre immédiatement aux requêtes de pré-vérification (Preflight OPTIONS)
  if (request.method === 'OPTIONS') {
    return new NextResponse(null, { status: 200, headers: corsHeaders })
  }

  // Injecter les headers CORS dans toutes les réponses API
  const response = NextResponse.next()
  corsHeaders.forEach((value, key) => {
    response.headers.set(key, value)
  })

  return response
}

export const config = {
  matcher: '/api/:path*',
}
