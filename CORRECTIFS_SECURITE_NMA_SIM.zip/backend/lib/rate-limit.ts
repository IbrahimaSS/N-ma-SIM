// =============================================
// LIMITATION DE DÉBIT SIMPLE (en mémoire, par clé)
// Utilisé pour F11 (brute-force login) et F18 (abus des endpoints IA)
// =============================================
// Limite : compte fenêtre glissante approximative en mémoire du process.
// Suffisant pour une seule instance serveur ; pour plusieurs instances en
// production, remplacer ce store par Redis (même interface).

interface Entry {
  count: number
  resetAt: number
}

const store = new Map<string, Entry>()

/**
 * Vérifie si `key` (ex: IP, email, ou "ip:email") a dépassé `max` tentatives
 * dans la fenêtre `windowMs`. Retourne true si la requête est autorisée.
 */
export function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now()
  const entry = store.get(key)

  if (!entry || now > entry.resetAt) {
    store.set(key, { count: 1, resetAt: now + windowMs })
    return true
  }

  if (entry.count >= max) {
    return false
  }

  entry.count += 1
  return true
}

/** Nettoyage périodique pour éviter une fuite mémoire sur un process long-vivant. */
setInterval(() => {
  const now = Date.now()
  for (const [key, entry] of store.entries()) {
    if (now > entry.resetAt) store.delete(key)
  }
}, 5 * 60 * 1000).unref?.()

/** Extrait une IP raisonnable depuis les headers d'une requête Next.js. */
export function getClientIp(request: Request): string {
  const forwarded = request.headers.get('x-forwarded-for')
  if (forwarded) return forwarded.split(',')[0].trim()
  return request.headers.get('x-real-ip') || 'unknown'
}
