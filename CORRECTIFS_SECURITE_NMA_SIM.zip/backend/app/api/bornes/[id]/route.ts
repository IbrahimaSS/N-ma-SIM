import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuthUser } from "@/lib/auth";

// Correctif F06 — toutes les méthodes exigent désormais un compte ADMIN ou TECHNICIEN.
function requireAdminOrTech(request: Request) {
  const authUser = getAuthUser(request);
  if (!authUser || !["ADMIN", "TECHNICIEN"].includes(authUser.role)) {
    return NextResponse.json({ success: false, message: "Accès refusé" }, { status: 403 });
  }
  return null;
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const forbidden = requireAdminOrTech(request);
  if (forbidden) return forbidden;

  try {
    const { id } = await context.params;
    const body = await request.json();

    if (!id) {
      return NextResponse.json({ success: false, message: "ID manquant." }, { status: 400 });
    }

    const borne = await prisma.borne.update({
      where: { id },
      data: body,
    });

    return NextResponse.json({ success: true, data: borne });
  } catch (error: any) {
    console.error("Erreur PATCH /bornes/[id]:", error);
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

export async function DELETE(request: Request, context: { params: Promise<{ id: string }> }) {
  const forbidden = requireAdminOrTech(request);
  if (forbidden) return forbidden;

  try {
    const { id } = await context.params;

    if (!id) {
      return NextResponse.json({ success: false, message: "ID manquant." }, { status: 400 });
    }

    await prisma.borne.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: "Borne supprimée." });
  } catch (error: any) {
    console.error("Erreur DELETE /bornes/[id]:", error);
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}
