import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getAuthUser } from "@/lib/auth";
import crypto from "crypto";

// Correctif F06 — toutes les méthodes exigent désormais un compte ADMIN ou TECHNICIEN.
function requireAdminOrTech(request: Request) {
  const authUser = getAuthUser(request);
  if (!authUser || !["ADMIN", "TECHNICIEN"].includes(authUser.role)) {
    return NextResponse.json({ success: false, message: "Accès refusé" }, { status: 403 });
  }
  return null;
}

export async function GET(request: Request) {
  const forbidden = requireAdminOrTech(request);
  if (forbidden) return forbidden;

  try {
    const bornes = await prisma.borne.findMany({
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ success: true, data: bornes });
  } catch (error: any) {
    console.error("Erreur GET /bornes:", error);
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const forbidden = requireAdminOrTech(request);
  if (forbidden) return forbidden;

  try {
    const body = await request.json();
    const { nom, emplacement } = body;

    if (!nom || !emplacement) {
      return NextResponse.json({ success: false, message: "Nom et emplacement sont requis." }, { status: 400 });
    }

    // Générer un ID BRN-XXX
    const count = await prisma.borne.count();
    const numeroReference = `BRN-${String(count + 1).padStart(3, "0")}`;

    // Correctif complémentaire — clé d'activation générée avec un générateur
    // cryptographiquement sûr (crypto.randomBytes) au lieu de Math.random(),
    // qui n'est pas conçu pour produire des secrets imprévisibles.
    const randomHex = () => crypto.randomBytes(3).toString("hex").toUpperCase();
    const cleActivation = `TKN-${randomHex()}-${randomHex()}-${randomHex()}`;

    const borne = await prisma.borne.create({
      data: {
        nom,
        emplacement,
        numeroReference,
        cleActivation,
        statut: "HORS_LIGNE",
      },
    });

    return NextResponse.json({ success: true, data: borne });
  } catch (error: any) {
    console.error("Erreur POST /bornes:", error);
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}
