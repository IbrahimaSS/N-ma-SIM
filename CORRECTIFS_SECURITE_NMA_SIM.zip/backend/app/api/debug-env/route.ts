import { NextResponse } from 'next/server'
import { getAuthUser } from '@/lib/auth'

// Correctif F08 — fuite d'information sur la configuration serveur.
// Ce endpoint de diagnostic est désormais désactivé en production,
// et réservé aux administrateurs authentifiés en dehors de la production.
export async function GET(request: Request) {
  if (process.env.NODE_ENV === 'production') {
    return NextResponse.json({ error: 'Not found' }, { status: 404 })
  }

  const authUser = getAuthUser(request)
  if (!authUser || authUser.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Not found' }, { status: 404 })
  }

  return NextResponse.json({
    hasDb: !!process.env.DATABASE_URL,
    hasJwt: !!process.env.JWT_SECRET,
    hasRefresh: !!process.env.REFRESH_TOKEN_SECRET,
    nodeEnv: process.env.NODE_ENV
  })
}
