import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getAuthUser, apiSuccess, apiError, isTrustedKiosk } from '@/lib/auth'
import { z } from 'zod'

const updateDemandeSchema = z.object({
  statut: z.enum(['EN_ATTENTE_VALIDATION', 'EN_COURS_DE_TRAITEMENT', 'VALIDEE', 'REJETEE']).optional(),
  commentaireAdmin: z.string().optional(),
  scoreVerification: z.number().optional(),
  verificationOCR: z.boolean().optional(),
  verificationSelfie: z.boolean().optional(),
})

/**
 * @swagger
 * /api/demandes/{id}:
 *   get:
 *     summary: Get SIM request by ID
 *     tags: [Demandes SIM]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: SIM request details
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: Not found
 */
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const authUser = getAuthUser(request)
    if (!authUser) return apiError('Non authentifié', 401)

    const { id } = await params

    const demande = await prisma.demandeSIM.findUnique({
      where: { id },
      include: {
        client: true,
        offre: true,
        paiement: true,
      }
    })

    if (!demande) return apiError('Demande introuvable', 404)

    return apiSuccess(demande)

  } catch (error) {
    console.error('[DEMANDE GET ID]', error)
    return apiError('Erreur interne', 500)
  }
}

/**
 * @swagger
 * /api/demandes/{id}:
 *   patch:
 *     summary: Update SIM request status
 *     description: Agent validates or rejects a SIM request (Auth required).
 *     tags: [Demandes SIM]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               statut:
 *                 type: string
 *                 enum: [EN_ATTENTE_VALIDATION, EN_COURS_DE_TRAITEMENT, VALIDEE, REJETEE]
 *               commentaireAdmin:
 *                 type: string
 *               scoreVerification:
 *                 type: number
 *               verificationOCR:
 *                 type: boolean
 *               verificationSelfie:
 *                 type: boolean
 *     responses:
 *       200:
 *         description: Demande updated
 *       401:
 *         description: Unauthorized
 */
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    // Accepte soit un admin authentifié, soit un appel interne de la borne
    // Correctif F04 — l'ancien en-tête littéral "x-internal-service: kiosk-borne"
    // (visible dans le code source public) est remplacé par un secret partagé
    // aléatoire comparé côté serveur. Voir lib/auth.ts > isTrustedKiosk().
    const authUser = getAuthUser(request)
    const isInternalService = isTrustedKiosk(request)

    if (!authUser && !isInternalService) return apiError('Non authentifié', 401)

    const { id } = await params
    const body = await request.json()
    const parsed = updateDemandeSchema.safeParse(body)

    if (!parsed.success) return apiError('Données invalides', 400, parsed.error.flatten())

    const demande = await prisma.demandeSIM.update({
      where: { id },
      data: {
        ...parsed.data,
        traitePar: authUser?.email || 'borne-automatique',
      },
      include: {
        client: { select: { nom: true, prenom: true } },
        offre: { select: { nom: true } },
      }
    })

    // Log
    if (parsed.data.statut) {
      const email = authUser?.email || 'Borne automatique';
      const uid = authUser?.id || null;
      
      await prisma.log.create({
        data: {
          type: `Demande ${parsed.data.statut}`,
          description: `Demande ${demande.numeroDossier} (${demande.client.nom} ${demande.client.prenom}) → ${parsed.data.statut} par ${email}`,
          entiteId: id,
          entiteType: 'DemandeSIM',
          utilisateurId: uid,
        }
      })
    }

    // Mettre à jour le statut du client en fonction de la demande
    if (parsed.data.statut === 'VALIDEE') {
      await prisma.client.update({
        where: { id: demande.clientId },
        data: { statut: 'VALIDE' }
      });
    } else if (parsed.data.statut === 'REJETEE') {
      await prisma.client.update({
        where: { id: demande.clientId },
        data: { statut: 'REJETE' }
      });
    }

    return apiSuccess(demande, 'Demande mise à jour')

  } catch (error) {
    console.error('[DEMANDE PATCH]', error)
    return apiError('Erreur interne', 500)
  }
}
